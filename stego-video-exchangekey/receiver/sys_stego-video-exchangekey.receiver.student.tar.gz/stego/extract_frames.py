import os
import subprocess

def extract_frames(video_path, output_folder, frame_pattern="frame_%04d.png"):
    os.makedirs(output_folder, exist_ok=True)
    cmd = f"ffmpeg -i {video_path} -qscale:v 2 {output_folder}/{frame_pattern}"
    subprocess.run(cmd, shell=True, check=True)
    print(f"[+] Extracted frame from {video_path} -> {output_folder}")

video_input = "testvid.mpg"
frames_folder = "frames"

print("\n[1] Tách frame và audio từ video gốc...")
extract_frames(video_input, frames_folder)

